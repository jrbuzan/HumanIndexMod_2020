# execute compile_HIM.wPython.sh
#modify him.jbuzan.contourlines.py
#execute him.jbuzan.contourlines.py

#python script is underconstruction. The provided script runs T -50-70°C and 0-100% RH at 100000Pa. This takes the old version of 
# HumanIndexMod and compares with the corrected version, and produces figures for comparison. 

# HumanIndexMod.CLM.F90 is the Fortran routine compatible with the Community Land Model (CLM), component model of the Community Earth System Model (CESM)
# maintained by the National Center for Atmospheric Research (NCAR).

#Good Luck

#Citation:
#Buzan, J. R., K. Oleson, and M. Huber (2015), Implementation and comparison of a suite of heat stress metrics within the Community Land Model version 4.5, Geosci. Model Dev., 8(2), 151–170, doi:10.5194/gmd-8-151-2015.

#Not for commercial use

